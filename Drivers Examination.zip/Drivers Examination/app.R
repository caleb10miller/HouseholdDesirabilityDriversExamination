library(shiny)
library(regclass)
library(multcompView)
library(stringr)
library(DALEX)
library(caret)
library(gbm)
library(randomForest)
library(pROC)
library(arules)
library(lubridate)
library(dplyr)

# Examine driver function
examine_driver <- function(formula,data,sort=TRUE,inside=TRUE,equal=TRUE) { 
  require(regclass)
  require(multcompView)
  require(stringr)
  
  FORM <- as.formula(formula)
  temp <- str_extract(FORM,"^.*==")
  temp <- temp[!is.na(temp)]
  y.label <- gsub(" ==","",temp)
  temp <- str_extract(FORM,'\\"[:alnum:]*')
  temp <- temp[!is.na(temp)]
  level <- substr(temp,2,nchar(temp))
  variables <- as.character(attr(terms(FORM), "variables"))[-1]
  x.label <- variables[2]
  data <- data[,c(x.label,y.label)]
  if (head(class(data[,y.label]),1) != "ordered") {
    data[,y.label] <- factor(data[,y.label])
  }
  data[,y.label] <- factor(data[,y.label],ordered=TRUE,levels=c(level,setdiff(levels(data[,y.label]),level)))
  if(nlevels(data[,y.label])>2) { levels(data[,y.label]) <- c(levels(data[,y.label])[1],rep(paste("Not",level),nlevels(data[,y.label])-1)) }
  x <- data[,x.label]
  y <- data[,y.label]
  
  color <- FALSE
  labelat=c(); xlab=c(); ylab=c(); magnification=1
  complete.x <- which(!is.na(x))
  complete.y <- which(!is.na(y))
  complete.cases <- intersect(complete.x, complete.y)
  x <- x[complete.cases]
  y <- y[complete.cases]
  if (head(class(x),1) != "ordered") {
    x <- factor(x)
  }
  if (head(class(y),1) != "ordered") {
    y <- factor(y)
  }
  data[,1] <- x
  data[,2] <- y
  n <- length(x)
  nx.levels <- length(unique(x))
  ny.levels <- length(unique(y))
  if (nx.levels < 2 | ny.levels < 2) {
    stop(paste("Error:  need at least 2 levels to proceed.  x has", 
               nx.levels, "and y has", ny.levels))
  }
  if (nx.levels > 100) {
    stop(paste("Error:  function not designed for more than 100 levels of x"))
  }
  
  xlevel.names <- levels(x)
  if(length(labelat)>0) { xlevel.names[!(xlevel.names %in% labelat)] <- "" }
  
  ylevel.names <- levels(y)
  CONT.TAB <- table(x, y)
  CONT.TAB <- addmargins(CONT.TAB)
  rownames(CONT.TAB)[nx.levels + 1] <- "Total"
  colnames(CONT.TAB)[ny.levels + 1] <- "Total"
  O <- matrix(table(x, y), nrow = nx.levels, ncol = ny.levels)
  E <- (apply(O, 1, sum) %o% apply(O, 2, sum))/n
  plot(0, 0, col = "white", xlim = c(0, 1.3), ylim = c(-0.05, 
                                                       1), xlab=ifelse(equal==TRUE,"",x.label),cex.main=0.7,main = "", ylab = paste("Probability",y.label,"is",level), axes = FALSE)
  if(equal==FALSE) { axis(1, at = seq(0, 1, 0.05)) }
  axis(2, at = seq(0, 1, 0.05))
  COLORS <- grey(seq(0.1, 0.7, length = ny.levels))
  marginal.y <- apply(O, 2, sum)/n
  break.y <- c(0, cumsum(marginal.y))
  for (i in 1:ny.levels) {
    rect(1.01, break.y[i], 1.11, break.y[i + 1], col = COLORS[i])
    text(1.1, (break.y[i + 1] + break.y[i])/2, ylevel.names[i], 
         srt = 0, pos = 4, cex = 1)
  }
  marginal.x <- apply(O, 1, sum)/n
  
  
  if(equal==FALSE) { break.x <- c(0, cumsum(marginal.x)) } else { break.x <- seq(0,1,length=1+length(xlevel.names)) }
  
  for (i in 1:nx.levels) {
    marginal.y <- O[i, ]/sum(O[i, ])
    break.y <- c(0, cumsum(marginal.y))
    for (j in 1:ny.levels) {
      rect(break.x[i], break.y[j], break.x[i + 1], break.y[j + 
                                                             1], col = COLORS[j])
    }
    if(inside==TRUE) { 
      text((break.x[i + 1] + break.x[i])/2, 0.5, xlevel.names[i],cex=magnification,srt=90,col="white")
    } else {
      text((break.x[i + 1] + break.x[i])/2, -0.05, xlevel.names[i],cex=magnification) }
    
  }
  lines(c(0,1),rep(mean(data[,y.label]==level),2),lwd=2,col="red")
  if(equal==TRUE) { text(0.5,-0.05,x.label)   }
  FORM3 <- formula(paste(y.label,"=='",level,"'~", x.label,sep=""))
  SUMMARY <- aggregate(FORM3,data=data,FUN=mean)
  AOV <- aov(FORM3,data=data)
  TUKEY <- TukeyHSD(AOV)
  LETTERS <- multcompLetters4(AOV,TUKEY) 
  SUMMARY$letters <- LETTERS[[1]][1]$Letters[match(SUMMARY[,1],names( LETTERS[[1]][1]$Letters ) )]
  SUMMARY$n <- as.numeric(table(data[,x.label]))
  names(SUMMARY)[2] <- paste("Prob",level,sep="")
  if(sort==TRUE) { SUMMARY <- SUMMARY[order(SUMMARY[,2],decreasing=TRUE),] }
  rownames(SUMMARY) <- NULL
  print(SUMMARY)
  R2 <- summary(lm( formula, data ) )[8]$r.squared
  cat(paste("\nDriver Score:",round(R2,digits=3),"\n"))
  cat(paste("Scores range between 0 and 1.  Larger scores = stronger driver.\n"))
  cat(paste("Although context dependent, values above 0.02 or so are 'reasonably strong' drivers.\n"))
}

input <- list()
input$driverchoice <- "view"
input$plottype <- "Tree"
input$cp = 0.001
input$numcats = 10
input$EqualBars <- TRUE
input$LabelInside <- TRUE
input$SortSelection = "Descending"
input$CombineRareLevels = 500

# Bring in data
Household <- read.csv('Case4-housedesirability.csv', stringsAsFactors = TRUE)
Household$price <- NULL
CopyZip <- Household$zipcode
Household <- discretizeDF(Household, default = list(method = 'frequency', breaks = input$numcats))
Household$zipcode <- as.factor(CopyZip)

# Define UI for application that draws a histogram
ui <- fluidPage(
  
  # Application title
  titlePanel("Houshold Desirability Data"),
  
  # Sidebar with a slider input for number of bins 
  sidebarLayout(
    sidebarPanel(
      selectInput(inputId="driverchoice", label="Select a Driver",choices=names(Household)),
      radioButtons(inputId="plottype",label="Choose Visualization",choices=c("Mosaic","Bar Chart","Tree")),
      sliderInput(inputId="numcats",label="Input number of categoreies",min=2,max=25,value=10,step=1),
      checkboxInput(inputId = "EqualBars", label = "Equal Bars", value = TRUE),
      checkboxInput(inputId = "LabelInside", label = "Label Inside", value = TRUE),
      sliderInput(inputId="cp",label="Tree Options",min=0,max=0.05,value=0.01,step=0.001),
      radioButtons(inputId = "SortSelection", label = "Sort Averages by:", choices = c('Ascending', 'Descending', 'A-Z'), selected = "Descending"),
      numericInput(inputId = "CombineRareLevels", label = "Combine categories appearing this many times or fewer:", value = 500)
    ),
    
    # Show a plot of the generated distribution
    mainPanel(
      plotOutput("maindriverplot"),
      textOutput("helpfullabel"),
      verbatimTextOutput("driversummary"),
    )
  )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
  
  output$maindriverplot <- renderPlot({
    
    if(input$plottype == "Mosaic") { 
      Household <- read.csv('Case4-housedesirability.csv', stringsAsFactors = TRUE)
      Household$price <- NULL
      CopyZip <- Household$zipcode
      Household <- discretizeDF(Household, default = list(method = 'frequency', breaks = input$numcats))
      Household$zipcode <- as.factor(CopyZip)
      
      if (input$CombineRareLevels > 0){Household[[input$driverchoice]] <- combine_rare_levels(Household[[input$driverchoice]], threshold = input$CombineRareLevels, newname = "Combined")$values}
      D = data.frame(list(Household[[input$driverchoice]]), Household$HighlyDesired)
      names(D) = c('x','y')
      
      EBtxt <- NULL
      INtxt <- NULL
      if (input$EqualBars == TRUE){EBtxt <- TRUE}else{EBtxt <- FALSE}
      if (input$LabelInside == TRUE){INtxt <- TRUE}else{INtxt <- FALSE}
      
      mosaic(y~x,data=D,equal = EBtxt,inside = INtxt)
      abline(h=1-mean(Household$HighlyDesired=='Yes'), col='blue')
    }   
    
    else if(input$plottype == "Bar Chart"){
      Household <- read.csv('Case4-housedesirability.csv', stringsAsFactors = TRUE)
      Household$price <- NULL
      CopyZip <- Household$zipcode
      Household <- discretizeDF(Household, default = list(method = 'frequency', breaks = input$numcats))
      Household$zipcode <- as.factor(CopyZip)
      
      if (input$CombineRareLevels > 0){Household[[input$driverchoice]] <- combine_rare_levels(Household[[input$driverchoice]], threshold = input$CombineRareLevels, newname = "Combined")$values}
      
      tbl <- aggregate(Household$HighlyDesired=='Yes', list(Household[[input$driverchoice]]), mean)
      data_bar <- tbl$x
      names(data_bar) <- tbl$Group.1
      Bar <- barplot(data_bar, main = 'Bar Chart', horiz = TRUE, las=1)
      abline(v=mean(Household$HighlyDesired=='Yes'))
    }
    
    else {
      if (input$CombineRareLevels > 0){Household[[input$driverchoice]] <- combine_rare_levels(Household[[input$driverchoice]], threshold = input$CombineRareLevels, newname = "Combined")$values}
      TREE <- rpart(HighlyDesired ~ ., data=Household, cp=input$cp)
      visualize_model(TREE)
    }
  })
  
  output$driversummary <- renderPrint({
    
    if( input$plottype == "Mosaic" | input$plottype == "Bar Chart" ) { 
      Household <- read.csv('Case4-housedesirability.csv', stringsAsFactors = TRUE)
      Household$price <- NULL
      CopyZip <- Household$zipcode
      Household <- discretizeDF(Household, default = list(method = 'frequency', breaks = input$numcats))
      Household$zipcode <- as.factor(CopyZip)
      
      if (input$CombineRareLevels > 0){Household[[input$driverchoice]] <- combine_rare_levels(Household[[input$driverchoice]], threshold = input$CombineRareLevels, newname = "Combined")$values}
      
      form <- formula( paste("HighlyDesired=='Yes' ~", input$driverchoice) )
      examine_driver(form, data=Household)  
    }
    else {
      if (input$CombineRareLevels > 0){Household[[input$driverchoice]] <- combine_rare_levels(Household[[input$driverchoice]], threshold = input$CombineRareLevels, newname = "Combined")$values}
      
      TREE <- rpart(HighlyDesired ~ ., data=Household, cp=input$cp)
      D <- data.frame( summarize_tree(TREE)$importance )
      names(D) <- "Driver"
      #if(input$SortSelection == "Descending"){dec <- TRUE}
      #else if (input$SortSelection == "Ascending"){dec <- FALSE}
  
      D$Driver <- round(D$Driver,digits=2)
      #D <- D[order(D$Driver), ]
      D
    }
    
  })
  
  output$helpfullabel <- renderPrint({
    
    if(input$plottype == "Main Driver") {
      
      cat( paste( "Display of how the probability of being highly desired changes with",input$driverchoice) )
      
    } else {
      cat( paste( "List of variable importances (higher = contributes more to the tree = stronger driver") )
    }
  })
}

# Run the application 
shinyApp(ui = ui, server = server)
